import { useEffect, useState } from 'react';
import api, { errMsg } from '../api/client';
import useToast from '../components/useToast';
import { Toast, Empty } from '../components/Layout';

const ROLES = { admin: 'ایڈمن', manager: 'منیجر', operator: 'منشی', viewer: 'صرف دیکھنا' };
const BLANK = { name: '', username: '', password: '', role: 'operator' };

export default function Users() {
  const { toast, show, clear } = useToast();
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState(null);
  const [pw, setPw] = useState({ currentPassword: '', newPassword: '' });

  const load = () => {
    setLoading(true);
    api
      .get('/users')
      .then(({ data }) => setRows(data.data))
      .catch((e) => show(errMsg(e), 'error'))
      .finally(() => setLoading(false));
  };

  useEffect(load, []); // eslint-disable-line react-hooks/exhaustive-deps

  const save = async (e) => {
    e.preventDefault();
    try {
      if (form.id) await api.put(`/users/${form.id}`, form);
      else await api.post('/users', form);
      show('محفوظ ہو گیا');
      setForm(null);
      load();
    } catch (err) {
      show(errMsg(err), 'error');
    }
  };

  const changePw = async (e) => {
    e.preventDefault();
    try {
      const { data } = await api.post('/auth/change-password', pw);
      show(data.message);
      setPw({ currentPassword: '', newPassword: '' });
    } catch (err) {
      show(errMsg(err), 'error');
    }
  };

  return (
    <>
      <Toast toast={toast} onClose={clear} />

      <div className="page-head">
        <div>
          <h1>یوزر</h1>
          <div className="sub">کون کیا کر سکتا ہے، یہاں سے طے ہوتا ہے</div>
        </div>
        <button className="btn" onClick={() => setForm({ ...BLANK })}>
          نیا یوزر
        </button>
      </div>

      {form && (
        <form className="card" onSubmit={save} style={{ marginBottom: '1rem' }}>
          <div className="card-title">{form.id ? 'یوزر میں ترمیم' : 'نیا یوزر'}</div>
          <div className="field-row">
            <div className="field">
              <label>نام</label>
              <input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
            </div>
            {!form.id && (
              <div className="field">
                <label>یوزر نیم</label>
                <input
                  required
                  className="num"
                  value={form.username}
                  onChange={(e) => setForm({ ...form, username: e.target.value })}
                />
              </div>
            )}
            <div className="field">
              <label>{form.id ? 'نیا پاس ورڈ (خالی چھوڑیں تو نہ بدلے)' : 'پاس ورڈ'}</label>
              <input
                type="password"
                required={!form.id}
                value={form.password || ''}
                onChange={(e) => setForm({ ...form, password: e.target.value })}
              />
            </div>
            <div className="field" style={{ maxWidth: 160 }}>
              <label>رول</label>
              <select value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })}>
                {Object.entries(ROLES).map(([k, v]) => (
                  <option key={k} value={k}>
                    {v}
                  </option>
                ))}
              </select>
            </div>
            <div className="field" style={{ flex: '0 0 auto' }}>
              <label>&nbsp;</label>
              <div className="split">
                <button className="btn gold">محفوظ کریں</button>
                <button type="button" className="btn ghost" onClick={() => setForm(null)}>
                  منسوخ
                </button>
              </div>
            </div>
          </div>
        </form>
      )}

      <div className="card">
        {loading ? (
          <div className="loading">لوڈ ہو رہا ہے…</div>
        ) : rows.length === 0 ? (
          <Empty>کوئی یوزر نہیں</Empty>
        ) : (
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>نام</th>
                  <th>یوزر نیم</th>
                  <th>رول</th>
                  <th>حالت</th>
                  <th />
                </tr>
              </thead>
              <tbody>
                {rows.map((u) => (
                  <tr key={u.id} className={u.isActive ? '' : 'dim'}>
                    <td>{u.name}</td>
                    <td className="num">{u.username}</td>
                    <td>{ROLES[u.role]}</td>
                    <td>
                      <span className={`chip ${u.isActive ? 'ok' : 'warn'}`}>{u.isActive ? 'فعال' : 'بند'}</span>
                    </td>
                    <td className="split">
                      <button className="btn ghost sm" onClick={() => setForm({ ...u, password: '' })}>
                        ترمیم
                      </button>
                      <button
                        className="btn ghost sm"
                        onClick={async () => {
                          await api.put(`/users/${u.id}`, { isActive: !u.isActive });
                          load();
                        }}
                      >
                        {u.isActive ? 'بند کریں' : 'کھولیں'}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <form className="card" onSubmit={changePw}>
        <div className="card-title">اپنا پاس ورڈ بدلیں</div>
        <div className="field-row">
          <div className="field">
            <label>موجودہ پاس ورڈ</label>
            <input
              type="password"
              required
              value={pw.currentPassword}
              onChange={(e) => setPw({ ...pw, currentPassword: e.target.value })}
            />
          </div>
          <div className="field">
            <label>نیا پاس ورڈ</label>
            <input
              type="password"
              required
              minLength={6}
              value={pw.newPassword}
              onChange={(e) => setPw({ ...pw, newPassword: e.target.value })}
            />
          </div>
          <div className="field" style={{ flex: '0 0 auto' }}>
            <label>&nbsp;</label>
            <button className="btn">بدلیں</button>
          </div>
        </div>
      </form>
    </>
  );
}
