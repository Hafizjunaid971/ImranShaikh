import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import api, { errMsg, fmtMoney, today } from '../api/client';
import { useAuth } from '../context/AuthContext';
import useToast from '../components/useToast';
import { Toast, Empty } from '../components/Layout';

const BLANK = { date: today(), reference: '', deposit: 0, withdraw: 0 };

export default function BankLedger() {
  const { id } = useParams();
  const { can } = useAuth();
  const { toast, show, clear } = useToast();
  const [range, setRange] = useState({ from: '', to: '' });
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState({ ...BLANK });

  const load = () => {
    setLoading(true);
    const qs = new URLSearchParams(Object.entries(range).filter(([, v]) => v)).toString();
    api
      .get(`/ledger/bank/${id}${qs ? `?${qs}` : ''}`)
      .then(({ data }) => setData(data))
      .catch((e) => show(errMsg(e), 'error'))
      .finally(() => setLoading(false));
  };

  useEffect(load, [id]); // eslint-disable-line react-hooks/exhaustive-deps

  const add = async (e) => {
    e.preventDefault();
    if (!form.deposit && !form.withdraw) return show('جمع یا نکالے میں سے کوئی ایک رقم لکھیں', 'error');
    try {
      await api.post(`/ledger/bank/${id}`, form);
      show('اندراج ہو گیا');
      setForm({ ...BLANK, date: form.date });
      load();
    } catch (err) {
      show(errMsg(err), 'error');
    }
  };

  const del = async (txnId) => {
    if (!confirm('یہ اندراج حذف کر دیں؟')) return;
    try {
      await api.delete(`/ledger/bank/${id}/${txnId}`);
      show('حذف ہو گیا');
      load();
    } catch (err) {
      show(errMsg(err), 'error');
    }
  };

  if (loading) return <div className="loading">لوڈ ہو رہا ہے…</div>;
  if (!data) return <Empty>اکاؤنٹ نہیں ملا</Empty>;

  const s = data.summary;

  return (
    <>
      <Toast toast={toast} onClose={clear} />

      <div className="page-head">
        <div>
          <h1>{data.account.title}</h1>
          <div className="sub num" style={{ direction: 'ltr', textAlign: 'right' }}>
            {data.account.bankName} — {data.account.accountNo}
          </div>
          <div className="sub">
            {data.account.branch} · <Link to="/banks">تمام اکاؤنٹ</Link>
          </div>
        </div>
        <div className="split">
          <div>
            <label>سے</label>
            <input type="date" value={range.from} onChange={(e) => setRange({ ...range, from: e.target.value })} />
          </div>
          <div>
            <label>تک</label>
            <input type="date" value={range.to} onChange={(e) => setRange({ ...range, to: e.target.value })} />
          </div>
          <button className="btn" onClick={load}>
            دکھائیں
          </button>
        </div>
      </div>

      <div className="grid grid-4">
        <div className="stat">
          <div className="stat-label">اوپننگ بیلنس</div>
          <div className="stat-value">{fmtMoney(s.openingBalance)}</div>
        </div>
        <div className="stat">
          <div className="stat-label">کل جمع</div>
          <div className="stat-value credit">{fmtMoney(s.totalDeposit)}</div>
        </div>
        <div className="stat">
          <div className="stat-label">کل نکالے</div>
          <div className="stat-value debit">{fmtMoney(s.totalWithdraw)}</div>
        </div>
        <div className="stat gold">
          <div className="stat-label">موجودہ بیلنس</div>
          <div className="stat-value">{fmtMoney(s.closingBalance)}</div>
        </div>
      </div>

      {can('admin', 'manager', 'operator') && (
        <form className="card" onSubmit={add} style={{ marginTop: '1rem' }}>
          <div className="card-title">نیا اندراج</div>
          <div className="field-row">
            <div className="field" style={{ maxWidth: 150 }}>
              <label>تاریخ</label>
              <input type="date" required value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} />
            </div>
            <div className="field" style={{ flex: 2 }}>
              <label>حوالہ / تفصیل</label>
              <input value={form.reference} onChange={(e) => setForm({ ...form, reference: e.target.value })} />
            </div>
            <div className="field" style={{ maxWidth: 150 }}>
              <label>جمع کرواے</label>
              <input
                className="num"
                type="number"
                value={form.deposit || ''}
                onChange={(e) => setForm({ ...form, deposit: Number(e.target.value || 0) })}
              />
            </div>
            <div className="field" style={{ maxWidth: 150 }}>
              <label>نکالے</label>
              <input
                className="num"
                type="number"
                value={form.withdraw || ''}
                onChange={(e) => setForm({ ...form, withdraw: Number(e.target.value || 0) })}
              />
            </div>
            <div className="field" style={{ flex: '0 0 auto' }}>
              <label>&nbsp;</label>
              <button className="btn gold">اندراج کریں</button>
            </div>
          </div>
        </form>
      )}

      <div className="card">
        <div className="card-title">اسٹیٹمنٹ</div>
        {data.rows.length === 0 ? (
          <Empty>اس دورانیے میں کوئی لین دین نہیں</Empty>
        ) : (
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th style={{ width: 40 }}>#</th>
                  <th>تاریخ</th>
                  <th>حوالہ</th>
                  <th className="num">جمع کرواے</th>
                  <th className="num">نکالے</th>
                  <th className="num">بقایہ</th>
                  <th />
                </tr>
              </thead>
              <tbody>
                {data.rows.map((r, i) => (
                  <tr key={r._id}>
                    <td className="muted num">{i + 1}</td>
                    <td className="num">{new Date(r.date).toISOString().slice(0, 10)}</td>
                    <td style={{ minWidth: 280 }}>{r.reference || '—'}</td>
                    <td className="num credit">{r.deposit ? fmtMoney(r.deposit) : '—'}</td>
                    <td className="num debit">{r.withdraw ? fmtMoney(r.withdraw) : '—'}</td>
                    <td className="num">{fmtMoney(r.balance)}</td>
                    <td>
                      {can('admin') && (
                        <button className="btn ghost sm" onClick={() => del(r._id)}>
                          حذف
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr>
                  <td colSpan={3}>ٹوٹل</td>
                  <td className="num">{fmtMoney(s.totalDeposit)}</td>
                  <td className="num">{fmtMoney(s.totalWithdraw)}</td>
                  <td className="num">{fmtMoney(s.closingBalance)}</td>
                  <td />
                </tr>
              </tfoot>
            </table>
          </div>
        )}
      </div>
    </>
  );
}
