import { useCallback, useEffect, useRef, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import api, { errMsg, fmtMoney, fmtNum, today } from '../api/client';
import { useAuth } from '../context/AuthContext';
import useToast from '../components/useToast';
import { Toast } from '../components/Layout';

/* چھوٹا ان پٹ سیل — خالی صفر نہ دکھائے */
function Cell({ value, onChange, disabled, width = 90, step = 'any', title }) {
  return (
    <input
      className="cell num"
      type="number"
      step={step}
      title={title}
      style={{ width }}
      disabled={disabled}
      value={value === 0 || value === null || value === undefined ? '' : value}
      onChange={(e) => onChange(e.target.value === '' ? 0 : Number(e.target.value))}
      onFocus={(e) => e.target.select()}
    />
  );
}

/** «100000+25000+8000» جیسی سٹرنگ کو قسطوں میں بدلتا ہے (Excel کی عادت) */
const parsePlus = (str) =>
  String(str || '')
    .split('+')
    .map((x) => Number(String(x).trim()))
    .filter((n) => Number.isFinite(n) && n !== 0);

const joinPlus = (arr = []) => arr.map((x) => x.weight ?? x.amount ?? x).filter(Boolean).join('+');

export default function DailySheet() {
  const { date: routeDate } = useParams();
  const navigate = useNavigate();
  const { can } = useAuth();
  const { toast, show, clear } = useToast();

  const [date, setDate] = useState(routeDate || today());
  const [sheet, setSheet] = useState(null);
  const [suppliers, setSuppliers] = useState([]);
  const [heads, setHeads] = useState([]);
  const [totals, setTotals] = useState(null);
  const [costing, setCosting] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [isNew, setIsNew] = useState(true);
  const [filter, setFilter] = useState('');
  const [onlyActive, setOnlyActive] = useState(false);

  const editable = can('admin', 'manager', 'operator') && !sheet?.isLocked;

  /* ------------------------------------------------------------ load ---- */
  const load = useCallback(async (d) => {
    setLoading(true);
    try {
      const [sh, sup, hd] = await Promise.all([
        api.get(`/daily/${d}`),
        api.get('/suppliers?active=true'),
        api.get('/expense-heads'),
      ]);
      setSuppliers(sup.data.data);
      setHeads(hd.data.data);
      setIsNew(sh.data.isNew);

      const s = sh.data.data;
      s.entries = s.entries.map((e) => ({
        ...e,
        customerId: e.customer?._id || e.customer,
        customerName: e.customerName || e.customer?.name,
        area: e.customer?.area,
        loadsText: joinPlus(e.loads),
        recoveryText: joinPlus(e.recoveries),
      }));
      s.purchases = s.purchases.map((p) => ({
        ...p,
        supplierId: p.supplier?._id || p.supplier || '',
      }));
      setSheet(s);
      setTotals(s.totals);
      setCosting(s.costing);
    } catch (e) {
      show(errMsg(e), 'error');
    } finally {
      setLoading(false);
    }
  }, [show]);

  useEffect(() => {
    load(date);
  }, [date, load]);

  /* ------------------------------------------- live totals from backend -- */
  const timer = useRef(null);
  const sheetRef = useRef(sheet);
  sheetRef.current = sheet;

  /* سرور کے جواب میں سے صرف حساب شدہ خانے */
  const pick = (c) =>
    c
      ? {
          weight: c.weight,
          amount: c.amount,
          totalAmount: c.totalAmount,
          recovery: c.recovery,
          closingBalance: c.closingBalance,
        }
      : {};

  /**
   * صرف اصل INPUT کی fingerprint۔ سرور کا جواب (رقم/ٹوٹل/بقایہ) اِس میں شامل نہیں،
   * ورنہ جواب خود اگلی کال چلا دیتا اور چکر بن جاتا۔
   */
  const inputKey = sheet
    ? JSON.stringify([
        sheet.entries.map((e) => [e.loadsText, e.rate, e.previousBalance, e.recoveryText]),
        sheet.purchases.map((p) => [p.weight, p.rate]),
        sheet.expenses.map((x) => x.amount),
        sheet.costing?.baseRate ?? null,
        sheet.costing?.shortWeight ?? null,
        sheet.costing?.manualShortValue ?? null,
      ])
    : '';

  useEffect(() => {
    if (!sheetRef.current) return;
    clearTimeout(timer.current);
    timer.current = setTimeout(async () => {
      const cur = sheetRef.current;
      if (!cur) return;
      const payload = {
        entries: cur.entries.map((e) => ({
          loads: parsePlus(e.loadsText).map((w) => ({ weight: w })),
          weight: parsePlus(e.loadsText).length ? 0 : e.weight,
          rate: e.rate,
          previousBalance: e.previousBalance,
          recoveries: parsePlus(e.recoveryText).map((a) => ({ amount: a })),
        })),
        purchases: cur.purchases.map((p) => ({ weight: p.weight, rate: p.rate })),
        expenses: cur.expenses.map((x) => ({ amount: x.amount })),
        costing: {
          baseRate: cur.costing?.baseRate,
          shortWeight: cur.costing?.shortWeight ?? null,
          manualShortValue: cur.costing?.manualShortValue ?? null,
        },
      };
      try {
        // حساب ہمیشہ backend کرتا ہے — فرنٹ اینڈ کوئی فارمولا نہیں چلاتا
        const { data } = await api.post('/daily/preview', payload);
        setTotals(data.data.totals);
        setCosting(data.data.costing);
        setSheet((prev) =>
          prev
            ? { ...prev, entries: prev.entries.map((e, i) => ({ ...e, ...pick(data.data.entries[i]) })) }
            : prev
        );
      } catch {
        /* خاموش — یوزر لکھتا رہے */
      }
    }, 400);
    return () => clearTimeout(timer.current);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [inputKey]);

  /* ---------------------------------------------------------- editing --- */
  const setEntry = (idx, patch) =>
    setSheet((s) => {
      const entries = [...s.entries];
      entries[idx] = { ...entries[idx], ...patch };
      return { ...s, entries };
    });

  const setPurchase = (idx, patch) =>
    setSheet((s) => {
      const purchases = [...s.purchases];
      purchases[idx] = { ...purchases[idx], ...patch };
      return { ...s, purchases };
    });

  const setExpense = (idx, patch) =>
    setSheet((s) => {
      const expenses = [...s.expenses];
      expenses[idx] = { ...expenses[idx], ...patch };
      return { ...s, expenses };
    });

  const addPurchaseRow = () =>
    setSheet((s) => ({
      ...s,
      purchases: [...s.purchases, { supplierId: '', supplierName: '', vehicleNo: '', weight: 0, rate: 0 }],
    }));

  const addExpenseRow = () =>
    setSheet((s) => ({ ...s, expenses: [...s.expenses, { head: '', headName: 'متفرق', amount: 0 }] }));

  /** پورے کالم پر ایک ہی ریٹ لگانے کے لیے — منشی کا وقت بچتا ہے */
  const applyRateToAll = () => {
    const v = Number(prompt('جن لائنوں میں وزن ہے اُن سب پر کون سی ریٹ لگائیں؟'));
    if (!Number.isFinite(v) || v <= 0) return;
    setSheet((s) => ({
      ...s,
      entries: s.entries.map((e) =>
        parsePlus(e.loadsText).length || e.weight ? { ...e, rate: v } : e
      ),
    }));
  };

  /* ------------------------------------------------------------- save --- */
  const save = async () => {
    setSaving(true);
    try {
      const body = {
        date,
        entries: sheet.entries.map((e) => ({
          customer: e.customerId,
          loads: parsePlus(e.loadsText).map((w) => ({ weight: w })),
          weight: parsePlus(e.loadsText).length ? 0 : e.weight,
          rate: e.rate,
          recoveries: parsePlus(e.recoveryText).map((a) => ({ amount: a, mode: 'cash' })),
          note: e.note,
        })),
        purchases: sheet.purchases
          .filter((p) => p.supplierId && (p.weight || p.rate))
          .map((p) => ({ supplier: p.supplierId, vehicleNo: p.vehicleNo, weight: p.weight, rate: p.rate })),
        expenses: sheet.expenses.map((x) => ({ head: x.head || undefined, headName: x.headName, amount: x.amount })),
        costing: sheet.costing,
      };
      const { data } = await api.post('/daily', body);
      show(data.message);
      setIsNew(false);
      await load(date);
    } catch (e) {
      show(errMsg(e), 'error');
    } finally {
      setSaving(false);
    }
  };

  const toggleLock = async () => {
    try {
      const { data } = await api.patch(`/daily/${date}/lock`, { isLocked: !sheet.isLocked });
      show(data.message);
      load(date);
    } catch (e) {
      show(errMsg(e), 'error');
    }
  };

  const postLedgers = async () => {
    try {
      const { data } = await api.post(`/daily/${date}/post`);
      show(`${data.message} — سپلائر ${data.supplierEntries}، بینک ${data.bankEntries}`);
    } catch (e) {
      show(errMsg(e), 'error');
    }
  };

  const shiftDay = (n) => {
    const d = new Date(date);
    d.setDate(d.getDate() + n);
    const nd = d.toISOString().slice(0, 10);
    setDate(nd);
    navigate(`/daily/${nd}`, { replace: true });
  };

  /* ------------------------------------------------------------ render -- */
  if (loading || !sheet) return <div className="loading">شیٹ لوڈ ہو رہی ہے…</div>;

  const rows = sheet.entries.filter((e) => {
    if (filter && !e.customerName?.includes(filter)) return false;
    if (onlyActive && !(parsePlus(e.loadsText).length || e.weight || parsePlus(e.recoveryText).length)) return false;
    return true;
  });

  return (
    <>
      <Toast toast={toast} onClose={clear} />

      <div className="page-head">
        <div>
          <h1>روزانہ شیٹ</h1>
          <div className="sub">
            {isNew ? 'نئی شیٹ — ہر گاہک کا پچھلا بقایہ خود بھر دیا گیا ہے' : 'محفوظ شدہ شیٹ'}
            {sheet.isLocked && <span className="chip warn" style={{ marginInlineStart: '.5rem' }}>بند</span>}
          </div>
        </div>

        <div className="split">
          <button className="btn ghost sm" onClick={() => shiftDay(-1)}>← پچھلا دن</button>
          <input
            type="date"
            style={{ width: 160 }}
            value={date}
            onChange={(e) => {
              setDate(e.target.value);
              navigate(`/daily/${e.target.value}`, { replace: true });
            }}
          />
          <button className="btn ghost sm" onClick={() => shiftDay(1)}>اگلا دن →</button>
        </div>
      </div>

      {/* ----------------------------------------------- گاہک کی لائنیں --- */}
      <div className="card">
        <div className="card-title">
          <span>گاہک ({rows.length})</span>
          <div className="split">
            <input
              placeholder="نام تلاش کریں"
              style={{ width: 170 }}
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
            />
            <label className="split" style={{ marginBottom: 0, gap: '.3rem' }}>
              <input
                type="checkbox"
                style={{ width: 'auto' }}
                checked={onlyActive}
                onChange={(e) => setOnlyActive(e.target.checked)}
              />
              صرف آج کے
            </label>
            {editable && (
              <button className="btn ghost sm" onClick={applyRateToAll}>
                سب پر ریٹ لگائیں
              </button>
            )}
          </div>
        </div>

        <div className="table-wrap" style={{ maxHeight: '62vh', overflowY: 'auto' }}>
          <table>
            <thead>
              <tr>
                <th style={{ width: 34 }}>#</th>
                <th className="sticky-name">نام</th>
                <th className="num">وزن</th>
                <th className="num">ریٹ</th>
                <th className="num">رقم</th>
                <th className="num">بقایہ رقم</th>
                <th className="num">ٹوٹل رقم</th>
                <th className="num">ریکوری جمع</th>
                <th className="num">نیا بقایہ</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((e) => {
                const i = sheet.entries.indexOf(e);
                const inactive = !e.weight && !e.recovery;
                return (
                  <tr key={e.customerId} className={inactive ? 'dim' : ''}>
                    <td className="muted num">{i + 1}</td>
                    <td className="sticky-name">
                      {e.customerName}
                      {e.area && <span className="muted"> — {e.area}</span>}
                    </td>
                    <td className="num">
                      <input
                        className="cell num"
                        style={{ width: 110 }}
                        disabled={!editable}
                        title="ایک سے زیادہ لوڈ ہوں تو + لگا کر لکھیں: 931.7+222.5"
                        value={e.loadsText}
                        onChange={(ev) => setEntry(i, { loadsText: ev.target.value })}
                        onFocus={(ev) => ev.target.select()}
                      />
                    </td>
                    <td className="num">
                      <Cell value={e.rate} disabled={!editable} width={70} onChange={(v) => setEntry(i, { rate: v })} />
                    </td>
                    <td className="num">{fmtMoney(e.amount)}</td>
                    <td className="num muted">{fmtMoney(e.previousBalance)}</td>
                    <td className="num">{fmtMoney(e.totalAmount)}</td>
                    <td className="num">
                      <input
                        className="cell num"
                        style={{ width: 150 }}
                        disabled={!editable}
                        title="کئی قسطیں ہوں تو + لگا کر: 100000+25000+8000"
                        value={e.recoveryText}
                        onChange={(ev) => setEntry(i, { recoveryText: ev.target.value })}
                        onFocus={(ev) => ev.target.select()}
                      />
                    </td>
                    <td className={`num ${e.closingBalance > 0 ? 'debit' : 'credit'}`}>
                      {fmtMoney(e.closingBalance)}
                    </td>
                  </tr>
                );
              })}
            </tbody>
            {totals && (
              <tfoot>
                <tr>
                  <td colSpan={2}>ٹوٹل</td>
                  <td className="num">{fmtNum(totals.weight)}</td>
                  <td className="num">{fmtNum(totals.avgRate)}</td>
                  <td className="num">{fmtMoney(totals.amount)}</td>
                  <td className="num">{fmtMoney(totals.previousBalance)}</td>
                  <td className="num">{fmtMoney(totals.totalAmount)}</td>
                  <td className="num">{fmtMoney(totals.recovery)}</td>
                  <td className="num">{fmtMoney(totals.closingBalance)}</td>
                </tr>
              </tfoot>
            )}
          </table>
        </div>
      </div>

      <div className="grid grid-2" style={{ marginTop: '1rem' }}>
        {/* ------------------------------------------------ خرید / سپلائی */}
        <div className="card">
          <div className="card-title">
            <span>خرید / سپلائی</span>
            {editable && (
              <button className="btn ghost sm" onClick={addPurchaseRow}>
                لائن بڑھائیں
              </button>
            )}
          </div>
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>سپلائر</th>
                  <th>گاڑی</th>
                  <th className="num">وزن</th>
                  <th className="num">ریٹ</th>
                  <th className="num">رقم</th>
                </tr>
              </thead>
              <tbody>
                {sheet.purchases.map((p, i) => (
                  <tr key={i}>
                    <td>
                      <select
                        disabled={!editable}
                        value={p.supplierId || ''}
                        onChange={(e) => {
                          const s = suppliers.find((x) => x._id === e.target.value);
                          setPurchase(i, {
                            supplierId: e.target.value,
                            supplierName: s?.name,
                            vehicleNo: p.vehicleNo || s?.vehicleNo || '',
                          });
                        }}
                      >
                        <option value="">— منتخب کریں —</option>
                        {suppliers.map((s) => (
                          <option key={s._id} value={s._id}>
                            {s.name}
                          </option>
                        ))}
                      </select>
                    </td>
                    <td>
                      <input
                        className="cell"
                        style={{ width: 60, textAlign: 'right' }}
                        disabled={!editable}
                        value={p.vehicleNo || ''}
                        onChange={(e) => setPurchase(i, { vehicleNo: e.target.value })}
                      />
                    </td>
                    <td className="num">
                      <Cell value={p.weight} disabled={!editable} onChange={(v) => setPurchase(i, { weight: v })} />
                    </td>
                    <td className="num">
                      <Cell value={p.rate} width={70} disabled={!editable} onChange={(v) => setPurchase(i, { rate: v })} />
                    </td>
                    <td className="num">{fmtMoney(Number(p.weight || 0) * Number(p.rate || 0))}</td>
                  </tr>
                ))}
              </tbody>
              {totals && (
                <tfoot>
                  <tr>
                    <td colSpan={2}>ٹوٹل خرید</td>
                    <td className="num">{fmtNum(totals.purchaseWeight)}</td>
                    <td className="num">{fmtNum(totals.purchaseAvgRate)}</td>
                    <td className="num">{fmtMoney(totals.purchaseAmount)}</td>
                  </tr>
                  <tr>
                    <td colSpan={2}>{totals.excessShortLabel}</td>
                    <td className={`num ${totals.excessShort < 0 ? 'debit' : 'credit'}`}>
                      {fmtNum(totals.excessShort)}
                    </td>
                    <td colSpan={2} className="muted">
                      فروخت کا وزن منفی خرید کا وزن
                    </td>
                  </tr>
                </tfoot>
              )}
            </table>
          </div>
        </div>

        {/* ------------------------------------------------------ خرچے */}
        <div className="card">
          <div className="card-title">
            <span>خرچے</span>
            {editable && (
              <button className="btn ghost sm" onClick={addExpenseRow}>
                خرچہ بڑھائیں
              </button>
            )}
          </div>
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>مد</th>
                  <th className="num">رقم</th>
                  <th>تفصیل</th>
                </tr>
              </thead>
              <tbody>
                {sheet.expenses.map((x, i) => (
                  <tr key={i}>
                    <td>
                      <select
                        disabled={!editable}
                        value={x.head || ''}
                        onChange={(e) => {
                          const h = heads.find((y) => y._id === e.target.value);
                          setExpense(i, { head: e.target.value, headName: h?.name || 'متفرق' });
                        }}
                      >
                        <option value="">متفرق</option>
                        {heads.map((h) => (
                          <option key={h._id} value={h._id}>
                            {h.name}
                          </option>
                        ))}
                      </select>
                    </td>
                    <td className="num">
                      <Cell value={x.amount} disabled={!editable} onChange={(v) => setExpense(i, { amount: v })} />
                    </td>
                    <td>
                      <input
                        className="cell"
                        style={{ width: '100%', textAlign: 'right' }}
                        disabled={!editable}
                        value={x.note || ''}
                        onChange={(e) => setExpense(i, { note: e.target.value })}
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
              {totals && (
                <tfoot>
                  <tr>
                    <td>کل خرچا</td>
                    <td className="num">{fmtMoney(totals.expenseTotal)}</td>
                    <td />
                  </tr>
                </tfoot>
              )}
            </table>
          </div>

          {/* --------------------------------------------------- کوسٹنگ */}
          {costing && (
            <div style={{ marginTop: '1rem' }}>
              <div className="card-title">کوسٹنگ</div>
              <div className="field-row">
                <div className="field" style={{ maxWidth: 130 }}>
                  <label>بنیادی ریٹ</label>
                  <input
                    className="num"
                    type="number"
                    disabled={!editable}
                    value={sheet.costing?.baseRate || ''}
                    onChange={(e) =>
                      setSheet((s) => ({ ...s, costing: { ...s.costing, baseRate: Number(e.target.value || 0) } }))
                    }
                  />
                </div>
                <div className="field" style={{ maxWidth: 130 }}>
                  <label>شارٹ وزن</label>
                  <input
                    className="num"
                    type="number"
                    placeholder={String(Math.abs(totals?.excessShort || 0))}
                    disabled={!editable}
                    value={sheet.costing?.shortWeight ?? ''}
                    onChange={(e) =>
                      setSheet((s) => ({
                        ...s,
                        costing: { ...s.costing, shortWeight: e.target.value === '' ? null : Number(e.target.value) },
                      }))
                    }
                  />
                </div>
                <div className="field" style={{ maxWidth: 150 }}>
                  <label>شارٹ کی مالیت</label>
                  <input className="num" readOnly value={fmtMoney(costing.shortValue)} />
                </div>
                <div className="field" style={{ maxWidth: 130 }}>
                  <label>فی کلو خرچہ</label>
                  <input className="num" readOnly value={fmtNum(costing.perKg, 2)} />
                </div>
                <div className="field" style={{ maxWidth: 140 }}>
                  <label>کوسٹنگ ریٹ</label>
                  <input className="num" readOnly value={fmtNum(costing.costingRate, 2)} />
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* ------------------------------------------------- pinned totals -- */}
      {totals && (
        <div className="rail">
          <div className="rail-item">
            <span>کل وزن</span>
            <b>{fmtNum(totals.weight)}</b>
          </div>
          <div className="rail-item">
            <span>اوسط ریٹ</span>
            <b>{fmtNum(totals.avgRate, 2)}</b>
          </div>
          <div className="rail-item">
            <span>کل فروخت</span>
            <b>{fmtMoney(totals.amount)}</b>
          </div>
          <div className="rail-item">
            <span>ریکوری</span>
            <b>{fmtMoney(totals.recovery)}</b>
          </div>
          <div className="rail-item">
            <span>بچت</span>
            <b>{fmtMoney(totals.grossProfit)}</b>
          </div>
          <div className="rail-item hero">
            <span>صافی بچت</span>
            <b>{fmtMoney(totals.netProfit)}</b>
          </div>

          <div className="spacer" />

          {can('admin', 'manager') && !isNew && (
            <>
              <button className="btn ghost sm" style={{ color: '#c3d0dc', borderColor: '#46596c' }} onClick={postLedgers}>
                لیجر میں بھیجیں
              </button>
              <button className="btn ghost sm" style={{ color: '#c3d0dc', borderColor: '#46596c' }} onClick={toggleLock}>
                {sheet.isLocked ? 'شیٹ کھولیں' : 'شیٹ بند کریں'}
              </button>
            </>
          )}
          {editable && (
            <button className="btn gold" onClick={save} disabled={saving}>
              {saving ? 'محفوظ ہو رہی ہے…' : 'شیٹ محفوظ کریں'}
            </button>
          )}
        </div>
      )}
    </>
  );
}
