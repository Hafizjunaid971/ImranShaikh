import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import api, { errMsg, fmtMoney, fmtNum, today } from '../api/client';
import { useAuth } from '../context/AuthContext';
import useToast from '../components/useToast';
import { Toast, Empty } from '../components/Layout';

const BLANK = { date: today(), vehicleNo: '', weight: 0, rate: 0, paid: 0, description: '' };

export default function SupplierLedger() {
  const { id } = useParams();
  const { can } = useAuth();
  const { toast, show, clear } = useToast();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState({ ...BLANK });

  const load = () => {
    setLoading(true);
    api
      .get(`/ledger/supplier/${id}`)
      .then(({ data }) => setData(data))
      .catch((e) => show(errMsg(e), 'error'))
      .finally(() => setLoading(false));
  };

  useEffect(load, [id]); // eslint-disable-line react-hooks/exhaustive-deps

  const add = async (e) => {
    e.preventDefault();
    try {
      await api.post(`/ledger/supplier/${id}`, form);
      show('اندراج ہو گیا');
      setForm({ ...BLANK, date: form.date });
      load();
    } catch (err) {
      show(errMsg(err), 'error');
    }
  };

  const del = async (txnId) => {
    if (!confirm('یہ اندراج حذف کر دیں؟')) return;
    try {
      await api.delete(`/ledger/supplier/${id}/${txnId}`);
      show('حذف ہو گیا');
      load();
    } catch (err) {
      show(errMsg(err), 'error');
    }
  };

  if (loading) return <div className="loading">لوڈ ہو رہا ہے…</div>;
  if (!data) return <Empty>کھاتہ نہیں ملا</Empty>;

  const s = data.summary;

  return (
    <>
      <Toast toast={toast} onClose={clear} />

      <div className="page-head">
        <div>
          <h1>{data.supplier.name}</h1>
          <div className="sub">
            {data.supplier.city || ''} · <Link to="/suppliers">تمام سپلائر</Link>
          </div>
        </div>
        <button className="btn ghost" onClick={() => window.print()}>
          پرنٹ
        </button>
      </div>

      <div className="grid grid-4">
        <div className="stat">
          <div className="stat-label">اوپننگ بیلنس</div>
          <div className="stat-value">{fmtMoney(s.openingBalance)}</div>
        </div>
        <div className="stat">
          <div className="stat-label">کل وزن</div>
          <div className="stat-value">{fmtNum(s.totalWeight, 1)}</div>
        </div>
        <div className="stat">
          <div className="stat-label">کل رقم</div>
          <div className="stat-value">{fmtMoney(s.totalAmount)}</div>
          <div className="stat-note">دیے {fmtMoney(s.totalPaid)}</div>
        </div>
        <div className="stat gold">
          <div className="stat-label">بقایہ</div>
          <div className="stat-value">{fmtMoney(s.closingBalance)}</div>
        </div>
      </div>

      {can('admin', 'manager', 'operator') && (
        <form className="card" onSubmit={add} style={{ marginTop: '1rem' }}>
          <div className="card-title">نیا اندراج</div>
          <div className="field-row">
            <div className="field" style={{ maxWidth: 150 }}>
              <label>تاریخ</label>
              <input type="date" required value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} />
            </div>
            <div className="field" style={{ maxWidth: 100 }}>
              <label>گاڑی</label>
              <input value={form.vehicleNo} onChange={(e) => setForm({ ...form, vehicleNo: e.target.value })} />
            </div>
            <div className="field" style={{ maxWidth: 120 }}>
              <label>وزن</label>
              <input
                className="num"
                type="number"
                step="any"
                value={form.weight || ''}
                onChange={(e) => setForm({ ...form, weight: Number(e.target.value || 0) })}
              />
            </div>
            <div className="field" style={{ maxWidth: 110 }}>
              <label>ریٹ</label>
              <input
                className="num"
                type="number"
                step="any"
                value={form.rate || ''}
                onChange={(e) => setForm({ ...form, rate: Number(e.target.value || 0) })}
              />
            </div>
            <div className="field" style={{ maxWidth: 140 }}>
              <label>دیے</label>
              <input
                className="num"
                type="number"
                step="any"
                value={form.paid || ''}
                onChange={(e) => setForm({ ...form, paid: Number(e.target.value || 0) })}
              />
            </div>
            <div className="field">
              <label>تفصیل</label>
              <input value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
            </div>
            <div className="field" style={{ flex: '0 0 auto' }}>
              <label>&nbsp;</label>
              <button className="btn gold">اندراج کریں</button>
            </div>
          </div>
          <p className="muted" style={{ fontSize: '.84rem', margin: '.5rem 0 0' }}>
            رقم = وزن × ریٹ، اور بقایہ = (رقم + پچھلا بیلنس) − دیے — یہ حساب سرور کرتا ہے۔
          </p>
        </form>
      )}

      <div className="card">
        <div className="card-title">کھاتہ</div>
        {data.rows.length === 0 ? (
          <Empty>ابھی کوئی اندراج نہیں</Empty>
        ) : (
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>تاریخ</th>
                  <th>گاڑی</th>
                  <th className="num">وزن</th>
                  <th className="num">ریٹ</th>
                  <th className="num">رقم</th>
                  <th className="num">پچھلا بیلنس</th>
                  <th className="num">ٹوٹل</th>
                  <th className="num">دیے</th>
                  <th className="num">بقایہ</th>
                  <th>تفصیل</th>
                  <th />
                </tr>
              </thead>
              <tbody>
                {data.rows.map((r) => (
                  <tr key={r._id}>
                    <td className="num">{new Date(r.date).toISOString().slice(0, 10)}</td>
                    <td className="num">{r.vehicleNo || '—'}</td>
                    <td className="num">{fmtNum(r.weight, 1)}</td>
                    <td className="num">{fmtNum(r.rate, 0)}</td>
                    <td className="num">{fmtMoney(r.amount)}</td>
                    <td className="num muted">{fmtMoney(r.previousBalance)}</td>
                    <td className="num">{fmtMoney(r.total)}</td>
                    <td className="num credit">{fmtMoney(r.paid)}</td>
                    <td className="num debit">{fmtMoney(r.balance)}</td>
                    <td style={{ minWidth: 200 }}>{r.description || '—'}</td>
                    <td>
                      {can('admin') && (
                        <button className="btn ghost sm" onClick={() => del(r._id)}>
                          حذف
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr>
                  <td colSpan={2}>ٹوٹل</td>
                  <td className="num">{fmtNum(s.totalWeight, 1)}</td>
                  <td />
                  <td className="num">{fmtMoney(s.totalAmount)}</td>
                  <td colSpan={2} />
                  <td className="num">{fmtMoney(s.totalPaid)}</td>
                  <td className="num">{fmtMoney(s.closingBalance)}</td>
                  <td colSpan={2} />
                </tr>
              </tfoot>
            </table>
          </div>
        )}
      </div>
    </>
  );
}
