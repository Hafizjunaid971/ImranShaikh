import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  ResponsiveContainer, ComposedChart, Line, Bar, XAxis, YAxis, Tooltip, CartesianGrid, Legend,
} from 'recharts';
import api, { errMsg, fmtMoney, fmtNum, monthKey } from '../api/client';
import useToast from '../components/useToast';
import { Toast, Empty } from '../components/Layout';

export default function Dashboard() {
  const { toast, show, clear } = useToast();
  const [month, setMonth] = useState(monthKey());
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    api
      .get(`/reports/dashboard?month=${month}`)
      .then(({ data }) => setData(data))
      .catch((e) => show(errMsg(e), 'error'))
      .finally(() => setLoading(false));
  }, [month, show]);

  if (loading) return <div className="loading">لوڈ ہو رہا ہے…</div>;
  if (!data) return <Empty>کوئی ڈیٹا نہیں</Empty>;

  const s = data.summary;
  const chart = data.trend.map((t) => ({
    din: new Date(t.date).getDate(),
    وزن: t.weight,
    'صافی بچت': t.netProfit,
    'اوسط ریٹ': t.avgRate,
    'کوسٹنگ ریٹ': t.costingRate,
  }));

  return (
    <>
      <Toast toast={toast} onClose={clear} />

      <div className="page-head">
        <div>
          <h1>ڈیش بورڈ</h1>
          <div className="sub">
            {s.days} دن کی شیٹیں — آخری اندراج{' '}
            {data.lastSheetDate ? new Date(data.lastSheetDate).toISOString().slice(0, 10) : '—'}
          </div>
        </div>
        <div className="split">
          <input type="month" value={month} onChange={(e) => setMonth(e.target.value)} style={{ width: 160 }} />
          <Link className="btn" to="/daily">
            آج کی شیٹ کھولیں
          </Link>
        </div>
      </div>

      <div className="grid grid-4">
        <div className="stat">
          <div className="stat-label">کل وزن (کلو)</div>
          <div className="stat-value">{fmtNum(s.saleWeight, 1)}</div>
          <div className="stat-note">اوسط ریٹ {fmtNum(s.avgSaleRate, 2)}</div>
        </div>
        <div className="stat">
          <div className="stat-label">کل فروخت</div>
          <div className="stat-value">{fmtMoney(s.saleAmount)}</div>
          <div className="stat-note">خرید {fmtMoney(s.purchaseAmount)}</div>
        </div>
        <div className="stat">
          <div className="stat-label">ریکوری</div>
          <div className="stat-value credit">{fmtMoney(s.recovery)}</div>
          <div className="stat-note">مہینے بھر کی وصولی</div>
        </div>
        <div className="stat gold">
          <div className="stat-label">صافی بچت</div>
          <div className="stat-value">{fmtMoney(s.netProfit)}</div>
          <div className="stat-note">
            فی کلو {fmtNum(s.netProfitPerKg, 2)} — خرچا {fmtMoney(s.expense)}
          </div>
        </div>
      </div>

      <div className="grid grid-4" style={{ marginTop: '1rem' }}>
        <div className="stat">
          <div className="stat-label">گاہکوں کا کل بقایہ</div>
          <div className="stat-value debit">{fmtMoney(s.customerOutstanding)}</div>
          <div className="stat-note">
            <Link to="/customers">تفصیل دیکھیں</Link>
          </div>
        </div>
        <div className="stat">
          <div className="stat-label">ایکسسز / شارٹ</div>
          <div className={`stat-value ${s.excessShort < 0 ? 'debit' : 'credit'}`}>{fmtNum(s.excessShort, 1)}</div>
          <div className="stat-note">مہینے کا مجموعہ (کلو)</div>
        </div>
        <div className="stat">
          <div className="stat-label">بچت (خرچے سے پہلے)</div>
          <div className="stat-value">{fmtMoney(s.grossProfit)}</div>
          <div className="stat-note">اوسط خرید ریٹ {fmtNum(s.avgPurchaseRate, 2)}</div>
        </div>
        <div className="stat">
          <div className="stat-label">بینک بیلنس</div>
          <div className="stat-value">{fmtMoney(data.banks.reduce((t, b) => t + b.balance, 0))}</div>
          <div className="stat-note">{data.banks.length} اکاؤنٹ</div>
        </div>
      </div>

      <div className="card" style={{ marginTop: '1rem' }}>
        <div className="card-title">روزانہ کارکردگی</div>
        {chart.length === 0 ? (
          <Empty>اس مہینے کی کوئی شیٹ نہیں</Empty>
        ) : (
          <div style={{ height: 320, direction: 'ltr' }}>
            <ResponsiveContainer>
              <ComposedChart data={chart} margin={{ top: 8, right: 12, bottom: 4, left: 4 }}>
                <CartesianGrid stroke="#ddd8cb" vertical={false} />
                <XAxis dataKey="din" tick={{ fontSize: 12 }} />
                <YAxis yAxisId="l" tick={{ fontSize: 12 }} />
                <YAxis yAxisId="r" orientation="right" tick={{ fontSize: 12 }} />
                <Tooltip formatter={(v) => fmtNum(v, 1)} />
                <Legend wrapperStyle={{ fontFamily: 'Noto Naskh Arabic', fontSize: 13 }} />
                <Bar yAxisId="l" dataKey="وزن" fill="#1b2a3a" barSize={14} />
                <Line yAxisId="r" dataKey="صافی بچت" stroke="#c9962b" strokeWidth={2} dot={false} />
                <Line yAxisId="r" dataKey="اوسط ریٹ" stroke="#1d6b4b" strokeWidth={1.5} dot={false} />
                <Line yAxisId="r" dataKey="کوسٹنگ ریٹ" stroke="#a63a2b" strokeWidth={1.5} strokeDasharray="4 3" dot={false} />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
        )}
      </div>

      <div className="card">
        <div className="card-title">بینک اکاؤنٹ</div>
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>اکاؤنٹ</th>
                <th>بینک</th>
                <th className="num">بیلنس</th>
              </tr>
            </thead>
            <tbody>
              {data.banks.map((b) => (
                <tr key={b.id}>
                  <td>
                    <Link to={`/banks/${b.id}`}>{b.title}</Link>
                  </td>
                  <td>{b.bankName}</td>
                  <td className={`num ${b.balance < 0 ? 'debit' : ''}`}>{fmtMoney(b.balance)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}
