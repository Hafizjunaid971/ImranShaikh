import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api, { errMsg, fmtMoney, fmtNum, today } from '../api/client';
import useToast from '../components/useToast';
import { Toast, Empty } from '../components/Layout';

const TABS = [
  { key: 'profit', label: 'روزانہ منافع' },
  { key: 'recovery', label: 'ریکوری اور بقایہ' },
  { key: 'expenses', label: 'خرچوں کی تقسیم' },
];

const firstOfMonth = () => {
  const d = new Date();
  return new Date(d.getFullYear(), d.getMonth(), 1).toISOString().slice(0, 10);
};

export default function Reports() {
  const { toast, show, clear } = useToast();
  const [tab, setTab] = useState('profit');
  const [range, setRange] = useState({ from: firstOfMonth(), to: today() });
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  const load = () => {
    setLoading(true);
    const qs = new URLSearchParams(range).toString();
    api
      .get(`/reports/${tab}?${qs}`)
      .then(({ data }) => setData(data))
      .catch((e) => show(errMsg(e), 'error'))
      .finally(() => setLoading(false));
  };

  useEffect(load, [tab]); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <>
      <Toast toast={toast} onClose={clear} />

      <div className="page-head">
        <div>
          <h1>رپورٹس</h1>
          <div className="sub">
            {range.from} سے {range.to} تک
          </div>
        </div>
        <div className="split">
          <input type="date" value={range.from} onChange={(e) => setRange({ ...range, from: e.target.value })} />
          <input type="date" value={range.to} onChange={(e) => setRange({ ...range, to: e.target.value })} />
          <button className="btn" onClick={load}>
            دکھائیں
          </button>
          <button className="btn ghost" onClick={() => window.print()}>
            پرنٹ
          </button>
        </div>
      </div>

      <div className="split" style={{ marginBottom: '1rem' }}>
        {TABS.map((t) => (
          <button
            key={t.key}
            className={`btn ${tab === t.key ? 'gold' : 'ghost'}`}
            onClick={() => setTab(t.key)}
          >
            {t.label}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="loading">لوڈ ہو رہا ہے…</div>
      ) : !data ? (
        <Empty>کوئی ڈیٹا نہیں</Empty>
      ) : tab === 'profit' ? (
        <ProfitTable data={data} />
      ) : tab === 'recovery' ? (
        <RecoveryTable data={data} />
      ) : (
        <ExpenseTable data={data} />
      )}
    </>
  );
}

function ProfitTable({ data }) {
  const t = data.totals;
  if (!data.rows.length) return <Empty>اس دورانیے کی کوئی شیٹ نہیں</Empty>;
  return (
    <>
      <div className="grid grid-4">
        <div className="stat">
          <div className="stat-label">کل وزن</div>
          <div className="stat-value">{fmtNum(t.saleWeight, 1)}</div>
        </div>
        <div className="stat">
          <div className="stat-label">کل فروخت</div>
          <div className="stat-value">{fmtMoney(t.saleAmount)}</div>
          <div className="stat-note">اوسط ریٹ {fmtNum(t.avgSaleRate, 2)}</div>
        </div>
        <div className="stat">
          <div className="stat-label">خرچے</div>
          <div className="stat-value debit">{fmtMoney(t.expense)}</div>
        </div>
        <div className="stat gold">
          <div className="stat-label">صافی بچت</div>
          <div className="stat-value">{fmtMoney(t.netProfit)}</div>
          <div className="stat-note">فی کلو {fmtNum(t.profitPerKg, 2)}</div>
        </div>
      </div>

      <div className="card" style={{ marginTop: '1rem' }}>
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>تاریخ</th>
                <th className="num">فروخت وزن</th>
                <th className="num">اوسط ریٹ</th>
                <th className="num">فروخت رقم</th>
                <th className="num">خرید وزن</th>
                <th className="num">خرید رقم</th>
                <th className="num">ایکسسز/شارٹ</th>
                <th className="num">بچت</th>
                <th className="num">خرچا</th>
                <th className="num">صافی بچت</th>
                <th className="num">کوسٹنگ ریٹ</th>
              </tr>
            </thead>
            <tbody>
              {data.rows.map((r) => (
                <tr key={r.date}>
                  <td className="num">
                    <Link to={`/daily/${new Date(r.date).toISOString().slice(0, 10)}`}>
                      {new Date(r.date).toISOString().slice(0, 10)}
                    </Link>
                  </td>
                  <td className="num">{fmtNum(r.saleWeight, 1)}</td>
                  <td className="num">{fmtNum(r.avgRate, 2)}</td>
                  <td className="num">{fmtMoney(r.saleAmount)}</td>
                  <td className="num">{fmtNum(r.purchaseWeight, 1)}</td>
                  <td className="num">{fmtMoney(r.purchaseAmount)}</td>
                  <td className={`num ${r.excessShort < 0 ? 'debit' : 'credit'}`}>{fmtNum(r.excessShort, 1)}</td>
                  <td className="num">{fmtMoney(r.grossProfit)}</td>
                  <td className="num debit">{fmtMoney(r.expense)}</td>
                  <td className={`num ${r.netProfit < 0 ? 'debit' : 'credit'}`}>{fmtMoney(r.netProfit)}</td>
                  <td className="num">{fmtNum(r.costingRate, 2)}</td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr>
                <td>ٹوٹل</td>
                <td className="num">{fmtNum(t.saleWeight, 1)}</td>
                <td className="num">{fmtNum(t.avgSaleRate, 2)}</td>
                <td className="num">{fmtMoney(t.saleAmount)}</td>
                <td className="num">{fmtNum(t.purchaseWeight, 1)}</td>
                <td className="num">{fmtMoney(t.purchaseAmount)}</td>
                <td className="num">{fmtNum(t.excessShort, 1)}</td>
                <td className="num">{fmtMoney(t.grossProfit)}</td>
                <td className="num">{fmtMoney(t.expense)}</td>
                <td className="num">{fmtMoney(t.netProfit)}</td>
                <td />
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
    </>
  );
}

function RecoveryTable({ data }) {
  const t = data.totals;
  if (!data.rows.length) return <Empty>کوئی ریکارڈ نہیں</Empty>;
  return (
    <div className="card">
      <div className="card-title">
        <span>گاہک وار</span>
        <span className="muted">
          بقایہ کل: <span className="num debit">{fmtMoney(t.balance)}</span>
        </span>
      </div>
      <div className="table-wrap">
        <table>
          <thead>
            <tr>
              <th style={{ width: 34 }}>#</th>
              <th>نام</th>
              <th className="num">دن</th>
              <th className="num">وزن</th>
              <th className="num">فروخت</th>
              <th className="num">ریکوری</th>
              <th className="num">بقایہ</th>
            </tr>
          </thead>
          <tbody>
            {data.rows.map((r, i) => (
              <tr key={r.customer}>
                <td className="muted num">{i + 1}</td>
                <td>
                  <Link to={`/customers/${r.customer}`}>{r.name}</Link>
                </td>
                <td className="num">{r.days}</td>
                <td className="num">{fmtNum(r.totalWeight, 1)}</td>
                <td className="num">{fmtMoney(r.totalSale)}</td>
                <td className="num credit">{fmtMoney(r.totalRecovery)}</td>
                <td className={`num ${r.lastBalance > 0 ? 'debit' : 'credit'}`}>{fmtMoney(r.lastBalance)}</td>
              </tr>
            ))}
          </tbody>
          <tfoot>
            <tr>
              <td colSpan={3}>ٹوٹل</td>
              <td className="num">{fmtNum(t.weight, 1)}</td>
              <td className="num">{fmtMoney(t.sale)}</td>
              <td className="num">{fmtMoney(t.recovery)}</td>
              <td className="num">{fmtMoney(t.balance)}</td>
            </tr>
          </tfoot>
        </table>
      </div>
    </div>
  );
}

function ExpenseTable({ data }) {
  if (!data.rows.length) return <Empty>کوئی خرچہ درج نہیں</Empty>;
  return (
    <div className="card">
      <div className="card-title">
        <span>خرچوں کی مدیں</span>
        <span className="muted num">{fmtMoney(data.total)}</span>
      </div>
      <div className="table-wrap">
        <table>
          <thead>
            <tr>
              <th>مد</th>
              <th className="num">اندراج</th>
              <th className="num">کل رقم</th>
              <th className="num">حصہ %</th>
            </tr>
          </thead>
          <tbody>
            {data.rows.map((r) => (
              <tr key={r.head}>
                <td>{r.head}</td>
                <td className="num">{r.count}</td>
                <td className="num">{fmtMoney(r.total)}</td>
                <td className="num">{fmtNum(r.share, 1)}%</td>
              </tr>
            ))}
          </tbody>
          <tfoot>
            <tr>
              <td colSpan={2}>ٹوٹل</td>
              <td className="num">{fmtMoney(data.total)}</td>
              <td className="num">100%</td>
            </tr>
          </tfoot>
        </table>
      </div>
    </div>
  );
}
