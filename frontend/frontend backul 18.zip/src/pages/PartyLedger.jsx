import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import api, { errMsg, fmtMoney, today } from '../api/client';
import { useAuth } from '../context/AuthContext';
import useToast from '../components/useToast';
import { Toast, Empty } from '../components/Layout';

const BLANK = { date: today(), reference: '', debit: 0, credit: 0 };

export default function PartyLedger() {
  const { party: routeParty } = useParams();
  const navigate = useNavigate();
  const { can } = useAuth();
  const { toast, show, clear } = useToast();

  const [parties, setParties] = useState([]);
  const [party, setParty] = useState(routeParty ? decodeURIComponent(routeParty) : '');
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({ ...BLANK });

  useEffect(() => {
    api
      .get('/ledger/parties')
      .then(({ data }) => {
        setParties(data.data);
        if (!party && data.data.length) {
          setParty(data.data[0]);
          navigate(`/party/${encodeURIComponent(data.data[0])}`, { replace: true });
        }
      })
      .catch((e) => show(errMsg(e), 'error'));
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const load = (p = party) => {
    if (!p) return;
    setLoading(true);
    api
      .get(`/ledger/party/${encodeURIComponent(p)}`)
      .then(({ data }) => setData(data))
      .catch((e) => show(errMsg(e), 'error'))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    load(party);
  }, [party]); // eslint-disable-line react-hooks/exhaustive-deps

  const add = async (e) => {
    e.preventDefault();
    if (!party) return show('پہلے پارٹی منتخب کریں', 'error');
    try {
      await api.post(`/ledger/party/${encodeURIComponent(party)}`, form);
      show('اندراج ہو گیا');
      setForm({ ...BLANK, date: form.date });
      load();
    } catch (err) {
      show(errMsg(err), 'error');
    }
  };

  const del = async (txnId) => {
    if (!confirm('یہ اندراج حذف کر دیں؟')) return;
    try {
      await api.delete(`/ledger/party/${encodeURIComponent(party)}/${txnId}`);
      show('حذف ہو گیا');
      load();
    } catch (err) {
      show(errMsg(err), 'error');
    }
  };

  const newParty = () => {
    const name = prompt('نئی پارٹی کا نام');
    if (!name) return;
    setParties((p) => [...new Set([...p, name])]);
    setParty(name);
    navigate(`/party/${encodeURIComponent(name)}`, { replace: true });
  };

  const s = data?.summary;

  return (
    <>
      <Toast toast={toast} onClose={clear} />

      <div className="page-head">
        <div>
          <h1>پارٹی لیجر</h1>
          <div className="sub">رقم آئے تو «جمع»، خرچ ہو تو «خرچہ» — بقایہ خود چلتا رہے گا</div>
        </div>
        <div className="split">
          <select
            style={{ width: 210 }}
            value={party}
            onChange={(e) => {
              setParty(e.target.value);
              navigate(`/party/${encodeURIComponent(e.target.value)}`, { replace: true });
            }}
          >
            <option value="">— پارٹی منتخب کریں —</option>
            {parties.map((p) => (
              <option key={p} value={p}>
                {p}
              </option>
            ))}
          </select>
          {can('admin', 'manager') && (
            <button className="btn ghost" onClick={newParty}>
              نئی پارٹی
            </button>
          )}
          <button className="btn ghost" onClick={() => window.print()}>
            پرنٹ
          </button>
        </div>
      </div>

      {s && (
        <div className="grid grid-4">
          <div className="stat">
            <div className="stat-label">اوپننگ</div>
            <div className="stat-value">{fmtMoney(s.openingBalance)}</div>
          </div>
          <div className="stat">
            <div className="stat-label">کل جمع</div>
            <div className="stat-value credit">{fmtMoney(s.totalDebit)}</div>
          </div>
          <div className="stat">
            <div className="stat-label">کل خرچہ</div>
            <div className="stat-value debit">{fmtMoney(s.totalCredit)}</div>
          </div>
          <div className="stat gold">
            <div className="stat-label">موجودہ بقایہ</div>
            <div className="stat-value">{fmtMoney(s.closingBalance)}</div>
          </div>
        </div>
      )}

      {party && can('admin', 'manager', 'operator') && (
        <form className="card" onSubmit={add} style={{ marginTop: '1rem' }}>
          <div className="card-title">نیا اندراج — {party}</div>
          <div className="field-row">
            <div className="field" style={{ maxWidth: 150 }}>
              <label>تاریخ</label>
              <input type="date" required value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} />
            </div>
            <div className="field" style={{ flex: 2 }}>
              <label>حوالہ</label>
              <input value={form.reference} onChange={(e) => setForm({ ...form, reference: e.target.value })} />
            </div>
            <div className="field" style={{ maxWidth: 150 }}>
              <label>جمع</label>
              <input
                className="num"
                type="number"
                value={form.debit || ''}
                onChange={(e) => setForm({ ...form, debit: Number(e.target.value || 0) })}
              />
            </div>
            <div className="field" style={{ maxWidth: 150 }}>
              <label>خرچہ</label>
              <input
                className="num"
                type="number"
                value={form.credit || ''}
                onChange={(e) => setForm({ ...form, credit: Number(e.target.value || 0) })}
              />
            </div>
            <div className="field" style={{ flex: '0 0 auto' }}>
              <label>&nbsp;</label>
              <button className="btn gold">اندراج کریں</button>
            </div>
          </div>
        </form>
      )}

      <div className="card">
        <div className="card-title">کھاتہ {party && `— ${party}`}</div>
        {loading ? (
          <div className="loading">لوڈ ہو رہا ہے…</div>
        ) : !data || data.rows.length === 0 ? (
          <Empty>ابھی کوئی اندراج نہیں</Empty>
        ) : (
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>تاریخ</th>
                  <th className="num">فروخت</th>
                  <th className="num">ریکوری</th>
                  <th className="num">جمع</th>
                  <th className="num">خرچہ</th>
                  <th>حوالہ</th>
                  <th className="num">بقایہ</th>
                  <th />
                </tr>
              </thead>
              <tbody>
                {data.rows.map((r) => (
                  <tr key={r._id} className={r.isBlankRow ? 'dim' : ''}>
                    <td className="num">{new Date(r.date).toISOString().slice(0, 10)}</td>
                    <td className="num muted">{r.saleAmount ? fmtMoney(r.saleAmount) : '—'}</td>
                    <td className="num muted">{r.recoveryAmount ? fmtMoney(r.recoveryAmount) : '—'}</td>
                    <td className="num credit">{r.debit ? fmtMoney(r.debit) : '—'}</td>
                    <td className="num debit">{r.credit ? fmtMoney(r.credit) : '—'}</td>
                    <td style={{ minWidth: 260 }}>{r.reference || '—'}</td>
                    <td className="num">{fmtMoney(r.balance)}</td>
                    <td>
                      {can('admin') && (
                        <button className="btn ghost sm" onClick={() => del(r._id)}>
                          حذف
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr>
                  <td colSpan={3}>ٹوٹل</td>
                  <td className="num">{fmtMoney(s.totalDebit)}</td>
                  <td className="num">{fmtMoney(s.totalCredit)}</td>
                  <td />
                  <td className="num">{fmtMoney(s.closingBalance)}</td>
                  <td />
                </tr>
              </tfoot>
            </table>
          </div>
        )}
      </div>
    </>
  );
}
