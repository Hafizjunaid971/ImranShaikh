import { useState } from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function Login() {
  const { user, login } = useAuth();
  const [form, setForm] = useState({ username: '', password: '' });
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);

  if (user) return <Navigate to="/" replace />;

  const submit = async (e) => {
    e.preventDefault();
    setErr('');
    setBusy(true);
    const res = await login(form.username.trim(), form.password);
    setBusy(false);
    if (!res.ok) setErr(res.message);
  };

  return (
    <div className="login-wrap">
      <form className="card login-card" onSubmit={submit}>
        <div className="login-title">کراچی مرغی سپلائی — لیجر</div>

        <div style={{ marginBottom: '.7rem' }}>
          <label htmlFor="u">یوزر نیم</label>
          <input
            id="u"
            autoFocus
            autoComplete="username"
            value={form.username}
            onChange={(e) => setForm({ ...form, username: e.target.value })}
          />
        </div>

        <div style={{ marginBottom: '1rem' }}>
          <label htmlFor="p">پاس ورڈ</label>
          <input
            id="p"
            type="password"
            autoComplete="current-password"
            value={form.password}
            onChange={(e) => setForm({ ...form, password: e.target.value })}
          />
        </div>

        {err && (
          <div className="chip warn" style={{ display: 'block', marginBottom: '.8rem', padding: '.4rem .7rem' }}>
            {err}
          </div>
        )}

        <button className="btn gold" style={{ width: '100%', justifyContent: 'center' }} disabled={busy}>
          {busy ? 'چیک ہو رہا ہے…' : 'لاگ اِن'}
        </button>

        <p className="muted" style={{ fontSize: '.82rem', marginTop: '1rem', marginBottom: 0 }}>
          پہلی بار: <span className="num">admin / admin123</span> — لاگ اِن کے بعد پاس ورڈ ضرور بدلیں۔
        </p>
      </form>
    </div>
  );
}
