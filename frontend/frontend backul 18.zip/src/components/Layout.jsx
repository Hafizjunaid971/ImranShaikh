import { NavLink, Outlet, Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const LINKS = [
  { to: '/', label: 'ڈیش بورڈ', end: true },
  { to: '/daily', label: 'روزانہ شیٹ' },
  { to: '/customers', label: 'گاہک اور بقایہ' },
  { to: '/suppliers', label: 'سپلائر / آڑتی' },
  { to: '/banks', label: 'بینک کھاتہ' },
  { to: '/party', label: 'پارٹی لیجر' },
  { to: '/reports', label: 'رپورٹس' },
];

export function Protected({ children }) {
  const { user, booting } = useAuth();
  if (booting) return <div className="loading">لوڈ ہو رہا ہے…</div>;
  if (!user) return <Navigate to="/login" replace />;
  return children;
}

export default function Layout() {
  const { user, logout, can } = useAuth();

  return (
    <div className="shell">
      <main className="main">
        <Outlet />
      </main>

      <nav className="nav">
        <div className="nav-brand">کراچی مرغی سپلائی</div>
        {LINKS.map((l) => (
          <NavLink key={l.to} to={l.to} end={l.end}>
            {l.label}
          </NavLink>
        ))}
        {can('admin') && <NavLink to="/users">یوزر</NavLink>}

        <div className="nav-foot">
          <div>{user?.name}</div>
          <div className="muted" style={{ fontSize: '.8rem' }}>
            {{ admin: 'ایڈمن', manager: 'منیجر', operator: 'منشی', viewer: 'صرف دیکھنا' }[user?.role]}
          </div>
          <button className="btn ghost sm" style={{ marginTop: '.5rem', color: '#c3d0dc', borderColor: '#46596c' }} onClick={logout}>
            لاگ آؤٹ
          </button>
        </div>
      </nav>
    </div>
  );
}

/* ---------------------------------------------------------- small helpers */

export function Toast({ toast, onClose }) {
  if (!toast) return null;
  return (
    <div className={`toast ${toast.type === 'error' ? 'err' : ''}`} onClick={onClose} role="status">
      {toast.message}
    </div>
  );
}

export function Empty({ children }) {
  return <div className="empty">{children}</div>;
}
